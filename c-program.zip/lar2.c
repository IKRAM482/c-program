#include<stdio.h>
void main()
{
  int a,b,c,large;
  printf("enter the number:");
  scanf("%d%d%d",&a,&b,&c);
  large=a;
  if(b>c)
  {
    large=b;
  }
  if(c>a)
  {
    large=c;
  }
  printf("the highest number=%d",large);
}