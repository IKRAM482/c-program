#include<stdio.h>
void main()
{
  int a[10],i,n;
  printf("enter the number:");
  scanf("%d",&n);
  printf("enter the array of element:");
  for (i=0;i<n;i++)
    {
      scanf("%d",&a[i]);
    }
  for(i=0;i<n;i++)
    {
      printf("the array of element=%d\n",a[i]);
    }
  }