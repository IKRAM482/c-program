#include<stdio.h>
main()
{
  int n,reverse=0,reaminder;
  printf("enter the number\n");
  scanf("%d",&n);
  while(n!=0)
    {
      reaminder=n%10;
      reverse=reverse*10+reaminder;
      n=n/10;
    }
  printf("reverse of number=%d\n",reverse);
}