#include<stdio.h>
main()
{
  int a,b,sum;
  printf("enter the number:");
  scanf("%d%d",&a,&b);
  sum=a+b;
  printf("the sum=%d\n",sum);
}