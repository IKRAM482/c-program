#include<stdio.h>
void main()
{
  int a[10],n,i,seclarge,large,small;
  printf("enter the number:");
  scanf("%d",&n);
  printf("enter the element of array:");
  for(i=0;i<n;i++)
    {
      scanf("%d",&a[i]);
    }
  large=a[0];
  small=a[0];
  for(i=0;i<n;i++)
    {
      if(a[i]>large)
      {
        seclarge=large;
        large=a[i];
      }
      if(a[i]<small)
      {
        small=a[i];
      }
    }
  printf("the largest no is=%d\n",large);
  printf("the smallest no is=%d\n",small);
  printf("the seclargest no is=%d\n",seclarge);
}
