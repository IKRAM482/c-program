#include<stdio.h>
void main()
{
  int n,remainder;
  printf("enter the number:");
  scanf("%d",&n);
  remainder=n%10;
  printf("the remainber is=%d",remainder);
  
}