#include<stdio.h>
main()
{
  int a,b,multi;
  printf("enter the number:");
  scanf("%d%d",&a,&b);
  multi=a*b;
  printf("the multiplication=%d\n",multi);
}