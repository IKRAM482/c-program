#include<stdio.h>
void main()
{
  int num1,num2,num,n,i;
  printf("enter the number:");
  scanf("%d",&n);
  num1=0;
  num2=1;
  printf("%d\n%d\n",num1,num2);
  i=3;
  while(i<=n)
    {
      num=num1+num2;
      printf("%d\n",num);
      num1=num2;
      num2=num;
      i++;
    }
}