#include<stdio.h>
void main()
{
  int n,i;
  printf("enter the number:");
  scanf("%d",&n);
  i=0;
  while(i<=n)
    {
      i++;
      printf("%d\n",i);
    }
}