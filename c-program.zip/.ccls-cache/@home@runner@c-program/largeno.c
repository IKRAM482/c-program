#include<stdio.h>
void main()
{
  int a,b,large;
  printf("enter the number:");
  scanf("%d%d",&a,&b);
  if(a>b)
  {
    printf("the highest num=%d",a);
  }
  else
  {
    printf("the highest num=%d",b);
  }
}