#include<stdio.h>
void main()
{
  int n,remainder,reverse=0,temp,i;
  printf("enter the number:");
  scanf("%d",&n);
  temp=n;
  while(n!=0)
    {
      remainder=n%10;
      reverse=reverse*10+remainder;
      n=n/10;
    }
  if(temp==n)
  {
    printf("the given num is paladurium");
  }
  else
  {
    printf("the given num is not paladurium");
  }
}