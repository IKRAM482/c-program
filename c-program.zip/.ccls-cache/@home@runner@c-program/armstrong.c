#include<stdio.h>
void main()
{
  int n,r,ar,sum=0,i;
  printf("enter the number:");
  scanf("%d",&n);
  while(n!=0)
    {
      r=n%10;
      ar=r*r*r;
      sum=sum+ar;
      n=n/10;
    }
  printf("the armsstrong number=%d",sum);
}