#include<stdio.h>
void main()
{
  int row,i=0,cl=0;
  printf("enter the no rows:");
  scanf("%d",&row);
  i=1;
  while(i<=row)
    {
      cl=i;
      while(cl!=0)
        {
            printf("*");
            cl--;
        }
      printf("\n");
      i++;
    }
  
}