#include<stdio.h>
main()
{
  float a,b,divide;
  printf("enter the number:");
  scanf("%f%f",&a,&b);
  divide=a/b;
  printf("the divide=%f\n",divide);
}