#include<stdio.h>
void main()
{
   int a[10],large=0,seclarge=0,n,i;
  printf("enter the number:");
  scanf("%d",&n);
  printf("enter the array of element:");
  for(i=0;i<n;i++)
  {
    scanf("%d",&a[i]);  
  }
  large=a[0];
  for(i=0;i<n;i++)
    {
     seclarge=large;
      large=a[i];
    }
  printf("the largest of number is %d\n",large);
  printf("the sec largest of number is %d\n",seclarge);
}