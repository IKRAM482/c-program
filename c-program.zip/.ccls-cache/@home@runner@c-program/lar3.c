#include<stdio.h>
void main()
{
  int a,b,c,d,large;
  printf("enter the number:");
  scanf("%d%d%d%d",&a,&b,&c,&d);
  large=a;
  if(b>a)
  {
    large=b;
  }
  if(c>d)
  {
    large=c;
  }
  if(d>a)
  {
    large=d;
  }
  printf("the highest of number=%d",large);
}