#include<stdio.h>
void main()
{
  int s1,s2,s3,s4,s5,s6,total,p,f;
  char r;
  float avg;
  printf("enter the numbers:");
  scanf("%d%d%d%d%d%d",&s1,&s2,&s3,&s4,&s5,&s6);
  total=s1+s2+s3+s4+s5+s6;
  printf("The toatal=%d\n",total);
  avg=total/6;
  printf("the precenatge=%f\n",avg);
  if(s1>=35 && s2>=35 && s3>=35 && s4>=35 && s5>=35 && s6>=35)
  {
    printf("the result is passed\n");
    r=p;
  }
  else{
    printf("the result is failed\n");
    r=f;
  }
  if(r==p)
  {
    if(total>=360)
    {
      printf("grade is frist class\n");
    }
    else if(total>=300){
      printf("grade is second class\n");
    }
    else if(total>=250)
    {
      printf("grade is thrid class\n");
    }
    else if(total>=200)
    {
      printf("grade is just passed\n");
    }
  }
  else {
    printf("grade is failed\n");
  }
}