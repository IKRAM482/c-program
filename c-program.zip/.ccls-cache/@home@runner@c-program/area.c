#include<stdio.h>
void main()
{
  float pi=3.14,r,area;
  printf("enter the number:");
  scanf("%f",&r);
  area=pi*r*r;
  printf("the area of circle=%f",area);
}