#include<stdio.h>
void main()
{
  int n,i;
  printf("enter the number:");
  scanf("%d",&n);
  i=0;
  while(i<=n)
    {
      i=i+2;
      printf("%d\n",i);
    }
}