#include<stdio.h>
main()
{
  int a,b,diff;
  printf("enter the number:");
  scanf("%d%d",&a,&b);
  diff=a-b;
  printf("the diff=%d\n",diff);
}